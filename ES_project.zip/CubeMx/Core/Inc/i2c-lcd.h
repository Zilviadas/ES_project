#include "stm32l0xx_hal.h"

void lcd_init (void);   							// Initialize lcd

void lcd_send_cmd (char cmd);  				// Send command to the lcd

void lcd_send_data (char data);  			// Send data to the lcd

void lcd_send_string (char *str);  		// Send string to the lcd

void lcd_put_cur(int row, int col); 	// Put cursor at the entered position row (0 or 1), col (0-15);

void lcd_clear (void);
